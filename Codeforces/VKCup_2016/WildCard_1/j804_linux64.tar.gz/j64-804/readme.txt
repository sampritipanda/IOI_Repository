
This is the J804 distribution.

For more information see: http://www.jsoftware.com/jwiki/System/Installation.

Shell scripts:

jconsole.sh        - load Jconsole (run in a terminal)

If the Qt IDE is already installed:
jqt.sh             - load JQt
updatejqt.sh       - update JQt binaries

You may create desktop shortcuts that call these scripts. Suitable icons are in the bin/icons directory.
