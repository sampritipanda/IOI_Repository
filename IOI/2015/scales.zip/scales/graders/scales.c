#include "scales.h"

void init(int T) {
    /* ... */
}

void orderCoins() {
    /* ... */
    int W[] = {1, 2, 3, 4, 5, 6};
    answer(W);
}