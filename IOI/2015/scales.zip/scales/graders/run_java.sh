#!/bin/bash

problem=scales

java -jar -Xmx1500M -Xms1400M -Xss64M $problem.jar
