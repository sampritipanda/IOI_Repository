general = {"score_mode": "max"}
checker = "checker-group-18.cpp"
sources = ["grader.c", "grader.cpp", "grader.pas", "scales.h", "graderlib.c", "grader.java", "graderlib.pas"]
datasets = {"primary":{"memory_limit" : 1500, "time_limit": 1.0, "score_type": "GroupMaybeSum", "score_type_parameters": [
    {
        "points": 100,
        "polygon_testset": "Tests"
    }
]}}